<?php

namespace App\Filament\Resources\DataScanResource\Pages;

use App\Filament\Resources\DataScanResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDataScan extends CreateRecord
{
    protected static string $resource = DataScanResource::class;
}
