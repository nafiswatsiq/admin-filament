<?php if (isset($component)) { $__componentOriginal511d4862ff04963c3c16115c05a86a9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal511d4862ff04963c3c16115c05a86a9d = $attributes; } ?>
<?php $component = Illuminate\View\DynamicComponent::resolve(['component' => $getFieldWrapperView()] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\DynamicComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => $field,'x-data' => '{
    allowsMultiple: '.e(json_encode($getAllowsMultiple())).',
    allowsUpload: '.e(json_encode($getAllowsUpload())).',
    allowsExisting: '.e(json_encode($getAllowsExisting())).',
    allowsOrderingImages: '.e(json_encode($getAllowsOrderingImages())).',
    state: $wire.$entangle(\''.e($getStatePath()).'\'),
    init() {
        const self = this;
        const sortable = ImageLibrarySortable.create(self.$refs.reorderContainer, {
            sort: true,
            handle: \'[data-reorder-handle]\',
            animation: 150,
            ghostClass: \'!bg-primary-500/20\',
            onUpdate: function(event) {
                self.state = sortable.toArray();
            },
        });
    },
}']); ?>
	<div
		class="grid grid-cols-2 gap-3 mb-2 xl:grid-cols-3"
		x-ref="reorderContainer"
	>
		<?php $__empty_1 = true; $__currentLoopData = $getImages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<div
				class="relative overflow-hidden bg-white rounded-lg ring-1 ring-gray-950/10 dark:ring-white/20"
				data-reorder-item
				data-id="<?php echo e($image->id); ?>"
				wire-key="<?php echo e($image->id); ?>-<?php echo e($getStatePath()); ?>"
			>
				<?php if (isset($component)) { $__componentOriginal310157662c158fee15e0626db88e7c9c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal310157662c158fee15e0626db88e7c9c = $attributes; } ?>
<?php $component = Outerweb\ImageLibrary\Components\Image::resolve(['image' => $image,'conversion' => 'filament-thumbnail'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('image-library-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Outerweb\ImageLibrary\Components\Image::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full','draggable' => 'false']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal310157662c158fee15e0626db88e7c9c)): ?>
<?php $attributes = $__attributesOriginal310157662c158fee15e0626db88e7c9c; ?>
<?php unset($__attributesOriginal310157662c158fee15e0626db88e7c9c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal310157662c158fee15e0626db88e7c9c)): ?>
<?php $component = $__componentOriginal310157662c158fee15e0626db88e7c9c; ?>
<?php unset($__componentOriginal310157662c158fee15e0626db88e7c9c); ?>
<?php endif; ?>
				<?php if($getAllowsImageCrop() || $getAllowsImageEdit() || $getAllowsImageDeselect()): ?>
					<div class="flex flex-wrap items-center justify-end gap-3 p-3">
						<?php if($getAllowsOrderingImages() && $getAllowsMultiple()): ?>
							<?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['icon' => 'heroicon-o-arrows-right-left','color' => 'gray','class' => 'mr-auto','tooltip' => ''.e(__('filament-image-library::translations.actions.reorder')).'','dataReorderHandle' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'heroicon-o-arrows-right-left','color' => 'gray','class' => 'mr-auto','tooltip' => ''.e(__('filament-image-library::translations.actions.reorder')).'','data-reorder-handle' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
						<?php endif; ?>
						<?php if($getAllowsImageCrop() && count($getAllowedConversionDefinitions()) > 0): ?>
							<?php echo e($getAction('crop')([
							    'id' => $image->id,
							])); ?>

						<?php endif; ?>
						<?php if($getAllowsImageEdit()): ?>
							<?php echo e($getAction('edit')([
							    'id' => $image->id,
							])); ?>

						<?php endif; ?>
						<?php if($getAllowsImageDeselect()): ?>
							<?php echo e($getAction('deselect')([
							    'id' => $image->id,
							])); ?>

						<?php endif; ?>
					</div>
				<?php endif; ?>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<div class="py-5 text-center text-gray-500 col-span-full">
				<p>
					<?php if($getAllowsMultiple()): ?>
						<?php echo e(__('filament-image-library::translations.form.messages.no_images_selected')); ?>

					<?php else: ?>
						<?php echo e(__('filament-image-library::translations.form.messages.no_image_selected')); ?>

					<?php endif; ?>
				</p>
				<p class="mt-2 text-sm">
					<?php if($getAllowsMultiple()): ?>
						<?php echo e(__('filament-image-library::translations.form.messages.upload_or_select_existing_multiple')); ?>

					<?php else: ?>
						<?php echo e(__('filament-image-library::translations.form.messages.upload_or_select_existing')); ?>

					<?php endif; ?>
				</p>
			</div>
		<?php endif; ?>
	</div>

	<div class="flex items-center justify-center gap-3">
		<?php if($getAllowsUpload()): ?>
			<?php echo e($getAction('upload')); ?>

		<?php endif; ?>
		<?php if($getAllowsExisting()): ?>
			<?php echo e($getAction('selectExisting')); ?>

		<?php endif; ?>
	</div>

	<?php if (isset($component)) { $__componentOriginal78918f4e4d2c3c3c2a4da34f24c77bf1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal78918f4e4d2c3c3c2a4da34f24c77bf1 = $attributes; } ?>
<?php $component = Outerweb\ImageLibrary\Components\Scripts::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('image-library-scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Outerweb\ImageLibrary\Components\Scripts::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal78918f4e4d2c3c3c2a4da34f24c77bf1)): ?>
<?php $attributes = $__attributesOriginal78918f4e4d2c3c3c2a4da34f24c77bf1; ?>
<?php unset($__attributesOriginal78918f4e4d2c3c3c2a4da34f24c77bf1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal78918f4e4d2c3c3c2a4da34f24c77bf1)): ?>
<?php $component = $__componentOriginal78918f4e4d2c3c3c2a4da34f24c77bf1; ?>
<?php unset($__componentOriginal78918f4e4d2c3c3c2a4da34f24c77bf1); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $attributes = $__attributesOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $component = $__componentOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__componentOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php /**PATH D:\Laravel-App\filament\vendor\outerweb\filament-image-library\resources\views\filament\forms\components\image-library-picker.blade.php ENDPATH**/ ?>