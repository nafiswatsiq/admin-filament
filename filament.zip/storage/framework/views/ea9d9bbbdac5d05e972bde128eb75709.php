<div
    class="<?php echo \Illuminate\Support\Arr::toCssClasses([
        'responsive' => $responsive
    ]); ?>"
>
    <iframe
        src="<?php echo e($url); ?>"
        width="<?php echo e($width); ?>"
        height="<?php echo e($height); ?>"
        style="aspect-ratio:<?php echo e($width); ?>/<?php echo e($height); ?>; width: 100%; height: auto;"
    />
</div><?php /**PATH D:\Laravel-App\filament\vendor\awcodes\filament-tiptap-editor\resources\views\components\blocks\previews\video.blade.php ENDPATH**/ ?>