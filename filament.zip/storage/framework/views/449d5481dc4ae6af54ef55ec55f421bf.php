<div>
    <?php
    $record = $getState();
    ?>

    <div class="flex gap-2 items-center">
        <img src="<?php echo e($record->avatar); ?>" alt="<?php echo e($record->{config('filamentblog.user.columns.name')}); ?>" class="w-7 h-7 rounded-full">
        <p class="text-xs font-semibold text-green-500"><?php echo e($record->name); ?></p>
    </div>
</div>
<?php /**PATH D:\Laravel-App\filament\resources\views\vendor\filament-blog\tables\columns\user-photo-name.blade.php ENDPATH**/ ?>