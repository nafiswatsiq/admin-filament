<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['post']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['post']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<form action="<?php echo e(route('filamentblog.comment.store', ['post' => $post->slug])); ?>" method="POST" id="comments">
    <?php echo csrf_field(); ?>
    <div class="border-t-2 py-10">
        <div class="mb-7">
            <h3 class="mb-2 text-2xl font-semibold">Leave a reply </h3>
        </div>
        <div class="mb-6">
            <label class="mb-2 block text-sm font-semibold" for="author-comment">Comment *</label>
            <textarea name="comment" rows="4" placeholder="Write your message here" type="text" id="author-comment"
                      class="form-input relative block w-full rounded-md border-0 bg-white px-4 py-4 text-sm text-gray-900 placeholder-gray-400 shadow-sm ring-1 ring-inset ring-gray-300 focus:outline-none focus:ring-2 focus:ring-black disabled:cursor-not-allowed disabled:opacity-75 dark:bg-gray-900 dark:text-white dark:placeholder-gray-500 dark:ring-gray-700"></textarea>
            <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php if(session('success')): ?>
                <span class="text-green-500"><?php echo e(session('success')); ?></span>
            <?php endif; ?>
        </div>
        <div>
            <?php if(auth()->user()?->canComment()): ?>
                <button type="submit"
                        class="g-recaptcha bg-primary-600 hover:bg-primary-700 rounded-lg px-8 py-4 font-semibold text-white transition-all duration-300"
                        <?php if(config('filamentblog.recaptcha.enabled')): ?> data-sitekey="<?php echo e(config('filamentblog.recaptcha.site_key')); ?>"
                        <?php endif; ?>
                        data-callback='onSubmit'
                        data-action='submit'
                >
                    <span>Post a comment</span>
                </button>
            <?php else: ?>
                <a
                        href="<?php echo e(route(config('filamentblog.route.login.name'))); ?>"
                        class="bg-primary-600 hover:bg-primary-700 rounded-lg px-8 py-4 font-semibold text-white transition-all duration-300">
                    <span>Login</span>
                </a>
            <?php endif; ?>
        </div>
    </div>
</form>
<?php /**PATH D:\Laravel-App\filament\resources\views\vendor\filament-blog\components\comment.blade.php ENDPATH**/ ?>