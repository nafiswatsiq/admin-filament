<?php if (isset($component)) { $__componentOriginal754011bc63f58e89b30dda00fb2be25c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal754011bc63f58e89b30dda00fb2be25c = $attributes; } ?>
<?php $component = Firefly\FilamentBlog\Components\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('blog-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Firefly\FilamentBlog\Components\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if(count($posts)): ?>
    <section class="py-8">
        <div class="container mx-auto">
            <div class="">
                
                <?php $__currentLoopData = $posts->take(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <?php if (isset($component)) { $__componentOriginal0d3e9b4ba6d2e5c89c33d06568a9b33c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0d3e9b4ba6d2e5c89c33d06568a9b33c = $attributes; } ?>
<?php $component = Firefly\FilamentBlog\Components\FeatureCard::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('blog-feature-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Firefly\FilamentBlog\Components\FeatureCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['post' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($post)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0d3e9b4ba6d2e5c89c33d06568a9b33c)): ?>
<?php $attributes = $__attributesOriginal0d3e9b4ba6d2e5c89c33d06568a9b33c; ?>
<?php unset($__attributesOriginal0d3e9b4ba6d2e5c89c33d06568a9b33c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0d3e9b4ba6d2e5c89c33d06568a9b33c)): ?>
<?php $component = $__componentOriginal0d3e9b4ba6d2e5c89c33d06568a9b33c; ?>
<?php unset($__componentOriginal0d3e9b4ba6d2e5c89c33d06568a9b33c); ?>
<?php endif; ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        </div>
    </section>
    <section class="pb-16 pt-8">
        <div class="container mx-auto">
            <div class="grid sm:grid-cols-3 gap-x-14 gap-y-14">
                <?php $__currentLoopData = $posts->skip(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginalc3b5c1399aa047ac4ad56a8d2bf46b04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc3b5c1399aa047ac4ad56a8d2bf46b04 = $attributes; } ?>
<?php $component = Firefly\FilamentBlog\Components\Card::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('blog-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Firefly\FilamentBlog\Components\Card::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['post' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($post)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc3b5c1399aa047ac4ad56a8d2bf46b04)): ?>
<?php $attributes = $__attributesOriginalc3b5c1399aa047ac4ad56a8d2bf46b04; ?>
<?php unset($__attributesOriginalc3b5c1399aa047ac4ad56a8d2bf46b04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3b5c1399aa047ac4ad56a8d2bf46b04)): ?>
<?php $component = $__componentOriginalc3b5c1399aa047ac4ad56a8d2bf46b04; ?>
<?php unset($__componentOriginalc3b5c1399aa047ac4ad56a8d2bf46b04); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="flex justify-center pt-20">
                <a href="<?php echo e(route('filamentblog.post.all')); ?>" class="flex items-center justify-center md:gap-x-5 rounded-full bg-slate-100 px-20 py-4 text-sm font-semibold transition-all duration-300 hover:bg-slate-200">
                    <span>Show all blogs</span>
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-6" viewBox="0 0 24 24">
                        <path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M6 18L18 6m0 0H9m9 0v9" />
                    </svg>
                </a>
            </div>
        </div>
    </section>
    <?php else: ?>
    <div class="container  mx-auto">
        <div class="flex justify-center">
            <p class="text-2xl font-semibold text-gray-300">No posts found</p>
        </div>
    </div>
    <?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal754011bc63f58e89b30dda00fb2be25c)): ?>
<?php $attributes = $__attributesOriginal754011bc63f58e89b30dda00fb2be25c; ?>
<?php unset($__attributesOriginal754011bc63f58e89b30dda00fb2be25c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal754011bc63f58e89b30dda00fb2be25c)): ?>
<?php $component = $__componentOriginal754011bc63f58e89b30dda00fb2be25c; ?>
<?php unset($__componentOriginal754011bc63f58e89b30dda00fb2be25c); ?>
<?php endif; ?>
<?php /**PATH D:\Laravel-App\filament\resources\views\vendor\filament-blog\blogs\index.blade.php ENDPATH**/ ?>