<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['post']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['post']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<a href="<?php echo e(route('filamentblog.post.show', ['post' => $post->slug])); ?>">
    <div class="group/blog-item flex flex-col gap-y-5">
        <div class="h-[250px] w-full rounded-xl bg-zinc-300 overflow-hidden">
            <img class="flex h-full w-full items-center justify-center object-cover object-top"
                 src="<?php echo e(asset($post->featurePhoto)); ?>" alt="<?php echo e($post->photo_alt_text); ?>">
        </div>
        <div class="flex flex-col justify-between space-y-3 px-2">
            <div>
                <h2 title="<?php echo e($post->title); ?>"
                    class="group-hover/blog-item:text-primary-700 mb-3 line-clamp-2 text-xl font-semibold hover:text-blue-600">
                    <?php echo e($post->title); ?>

                </h2>
                <p class="mb-3 line-clamp-3">
                    <?php echo e(Str::limit($post->sub_title, 100)); ?>

                </p>
            </div>
            <div class="flex items-center gap-4">
                <img class="h-10 w-10 overflow-hidden rounded-full bg-zinc-300 object-cover text-[0]"
                     src="<?php echo e($post->user->avatar); ?>" alt="<?php echo e($post->user->name()); ?>">
                <div>
                    <span title="<?php echo e($post->user->name()); ?>"
                          class="block max-w-[150px] overflow-hidden text-ellipsis whitespace-nowrap text-sm font-semibold"><?php echo e($post->user->name()); ?></span>
                    <span
                        class="block whitespace-nowrap text-sm font-medium font-semibold text-zinc-600">
                                            <?php echo e($post->formattedPublishedDate()); ?></span>
                </div>
            </div>
        </div>
    </div>
</a>
<?php /**PATH D:\Laravel-App\filament\resources\views\vendor\filament-blog\components\card.blade.php ENDPATH**/ ?>