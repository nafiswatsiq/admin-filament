<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a class="text-rum-800 hover:text-primary-700 py-4" href="<?php echo e(route('post.show', ['post' => $post->slug])); ?>">
        <h3 class="text-base font-medium">
            <?php echo e($post->title); ?>

        </h3>
    </a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\Laravel-App\filament\resources\views\vendor\filament-blog\components\recent-post.blade.php ENDPATH**/ ?>