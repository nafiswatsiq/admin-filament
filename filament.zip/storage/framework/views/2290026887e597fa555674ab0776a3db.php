<?php if (isset($component)) { $__componentOriginal511d4862ff04963c3c16115c05a86a9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal511d4862ff04963c3c16115c05a86a9d = $attributes; } ?>
<?php $component = Illuminate\View\DynamicComponent::resolve(['component' => $getEntryWrapperView()] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\DynamicComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['entry' => $entry]); ?>
	<div class="grid grid-cols-2 gap-3 mb-2 xl:grid-cols-3">
		<?php $__empty_1 = true; $__currentLoopData = $getImages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<div
				class="relative overflow-hidden bg-white rounded-lg ring-1 ring-gray-950/10 dark:ring-white/20"
				data-reorder-item
				data-id="<?php echo e($image->id); ?>"
				wire-key="<?php echo e($image->id); ?>-<?php echo e($getStatePath()); ?>"
			>
				<?php if (isset($component)) { $__componentOriginal310157662c158fee15e0626db88e7c9c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal310157662c158fee15e0626db88e7c9c = $attributes; } ?>
<?php $component = Outerweb\ImageLibrary\Components\Image::resolve(['image' => $image,'conversion' => 'filament-thumbnail'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('image-library-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Outerweb\ImageLibrary\Components\Image::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full','draggable' => 'false']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal310157662c158fee15e0626db88e7c9c)): ?>
<?php $attributes = $__attributesOriginal310157662c158fee15e0626db88e7c9c; ?>
<?php unset($__attributesOriginal310157662c158fee15e0626db88e7c9c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal310157662c158fee15e0626db88e7c9c)): ?>
<?php $component = $__componentOriginal310157662c158fee15e0626db88e7c9c; ?>
<?php unset($__componentOriginal310157662c158fee15e0626db88e7c9c); ?>
<?php endif; ?>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<div>
				<?php echo e($getPlaceholder()); ?>

			</div>
		<?php endif; ?>
	</div>

	<?php if (isset($component)) { $__componentOriginal78918f4e4d2c3c3c2a4da34f24c77bf1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal78918f4e4d2c3c3c2a4da34f24c77bf1 = $attributes; } ?>
<?php $component = Outerweb\ImageLibrary\Components\Scripts::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('image-library-scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Outerweb\ImageLibrary\Components\Scripts::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal78918f4e4d2c3c3c2a4da34f24c77bf1)): ?>
<?php $attributes = $__attributesOriginal78918f4e4d2c3c3c2a4da34f24c77bf1; ?>
<?php unset($__attributesOriginal78918f4e4d2c3c3c2a4da34f24c77bf1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal78918f4e4d2c3c3c2a4da34f24c77bf1)): ?>
<?php $component = $__componentOriginal78918f4e4d2c3c3c2a4da34f24c77bf1; ?>
<?php unset($__componentOriginal78918f4e4d2c3c3c2a4da34f24c77bf1); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $attributes = $__attributesOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $component = $__componentOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__componentOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php /**PATH D:\Laravel-App\filament\vendor\outerweb\filament-image-library\resources\views\filament\infolists\components\image-library-entry.blade.php ENDPATH**/ ?>