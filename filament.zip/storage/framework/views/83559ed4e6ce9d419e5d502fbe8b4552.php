<?php if (isset($component)) { $__componentOriginal754011bc63f58e89b30dda00fb2be25c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal754011bc63f58e89b30dda00fb2be25c = $attributes; } ?>
<?php $component = Firefly\FilamentBlog\Components\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('blog-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Firefly\FilamentBlog\Components\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section>
        <header class="container mx-auto mb-4 max-w-[800px] px-6 pb-4 mt-10 text-center">
            <p class="inherits-color text-balance leading-tighter relative z-10 text-3xl font-semibold tracking-tight">
                Category: <?php echo e($category->name); ?>

            </p>
        </header>
    </section>
    <section class="pb-16 pt-8">
        <div class="container mx-auto">
            <div class="grid grid-cols-3 gap-x-14 gap-y-14">
                <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                   <?php if (isset($component)) { $__componentOriginalc3b5c1399aa047ac4ad56a8d2bf46b04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc3b5c1399aa047ac4ad56a8d2bf46b04 = $attributes; } ?>
<?php $component = Firefly\FilamentBlog\Components\Card::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('blog-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Firefly\FilamentBlog\Components\Card::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['post' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($post)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc3b5c1399aa047ac4ad56a8d2bf46b04)): ?>
<?php $attributes = $__attributesOriginalc3b5c1399aa047ac4ad56a8d2bf46b04; ?>
<?php unset($__attributesOriginalc3b5c1399aa047ac4ad56a8d2bf46b04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3b5c1399aa047ac4ad56a8d2bf46b04)): ?>
<?php $component = $__componentOriginalc3b5c1399aa047ac4ad56a8d2bf46b04; ?>
<?php unset($__componentOriginalc3b5c1399aa047ac4ad56a8d2bf46b04); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="mx-auto col-span-3">
                        <div class="flex items-center justify-center">
                            <p class="text-2xl font-semibold text-gray-300">No posts found</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <div class="mt-20">
                <?php echo e($posts->links()); ?>

            </div>
        </div>
    </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal754011bc63f58e89b30dda00fb2be25c)): ?>
<?php $attributes = $__attributesOriginal754011bc63f58e89b30dda00fb2be25c; ?>
<?php unset($__attributesOriginal754011bc63f58e89b30dda00fb2be25c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal754011bc63f58e89b30dda00fb2be25c)): ?>
<?php $component = $__componentOriginal754011bc63f58e89b30dda00fb2be25c; ?>
<?php unset($__componentOriginal754011bc63f58e89b30dda00fb2be25c); ?>
<?php endif; ?>
<?php /**PATH D:\Laravel-App\filament\resources\views\vendor\filament-blog\blogs\category-post.blade.php ENDPATH**/ ?>