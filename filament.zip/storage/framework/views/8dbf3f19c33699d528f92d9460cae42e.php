<td
    <?php echo e($attributes->class(['fi-ta-summary-header-cell px-3 py-2 text-sm font-medium text-gray-950 dark:text-white sm:first-of-type:ps-6'])); ?>

>
    <?php echo e($slot); ?>

</td>
<?php /**PATH D:\Laravel-App\filament\vendor\filament\tables\resources\views\components\summary\header-cell.blade.php ENDPATH**/ ?>