<?php if (isset($component)) { $__componentOriginal511d4862ff04963c3c16115c05a86a9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal511d4862ff04963c3c16115c05a86a9d = $attributes; } ?>
<?php $component = Illuminate\View\DynamicComponent::resolve(['component' => $getFieldWrapperView()] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\DynamicComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => $field,'x-data' => '{
    state: $wire.$entangle(\''.e($getStatePath()).'\'),
    cropper: null,
    cropperLoaded: false,
    initialStateSet: false,
    initCropper() {
        const self = this;
        self.cropperLoaded = false;
        self.initialStateSet = false;
        self.cropper = new ImageLibraryCropper(document.getElementById(\'cropper-'.e($getImage()->uuid).'-'.e($getConversion()->id).'\'), {
            aspectRatio: '.e($getConversionAspectRatio()).',
            viewMode: 2,
            dragMode: \'move\',
            ready() {
                self.cropper.setData({
                    width: self.state.width,
                    height: self.state.height,
                    x: self.state.x,
                    y: self.state.y,
                });
                self.initialStateSet = true;
            },
            crop(event) {
                if (!self.initialStateSet) {
                    return;
                }

                self.state = {
                    ...self.state,
                    width: Math.round(event.detail.width),
                    height: Math.round(event.detail.height),
                    x: Math.round(event.detail.x),
                    y: Math.round(event.detail.y),
                };
            },
        });
        setTimeout(() => {
            self.cropperLoaded = true;
        }, 400);
    },
    init() {
        const self = this;

        if (self.state === null) {
            return;
        }

        if (this.tab) {
            this.$watch(\'tab\', function(value, oldValue) {
                if (value !== oldValue) {
                    self.cropper.destroy();
                    self.initCropper();
                }
            });
        }

        if (self.cropper) {
            self.cropper.destroy();
        }

        self.$nextTick(() => {
            setTimeout(() => {
                self.initCropper();
            }, 100);
        });
    },
}']); ?>
	<div
		class="w-full aspect-[4/3] max-w-full relative overflauto"
		data-cropper-container
		x-on:visible="alert('visible')"
	>
		<div class="w-full h-full z-0">
			<img
				wire:ignore
				src="<?php echo e($getImage()->getUrl()); ?>"
				id="cropper-<?php echo e($getImage()->uuid); ?>-<?php echo e($getConversion()->id); ?>"
				wire:key="filament-image-library::cropper-<?php echo e($getImage()->uuid); ?>-<?php echo e($getConversion()->id); ?>"
				class="block max-w-full"
				x-on:focus="init"
			>
		</div>
		<div
			class="absolute inset-0 w-full h-full bg-gray-50 flex items-center justify-center z-10"
			x-show="!cropperLoaded"
		>
			<?php if (isset($component)) { $__componentOriginalbef7c2371a870b1887ec3741fe311a10 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbef7c2371a870b1887ec3741fe311a10 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.loading-indicator','data' => ['class' => 'h-5 w-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::loading-indicator'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-5 w-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbef7c2371a870b1887ec3741fe311a10)): ?>
<?php $attributes = $__attributesOriginalbef7c2371a870b1887ec3741fe311a10; ?>
<?php unset($__attributesOriginalbef7c2371a870b1887ec3741fe311a10); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbef7c2371a870b1887ec3741fe311a10)): ?>
<?php $component = $__componentOriginalbef7c2371a870b1887ec3741fe311a10; ?>
<?php unset($__componentOriginalbef7c2371a870b1887ec3741fe311a10); ?>
<?php endif; ?>
		</div>
	</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $attributes = $__attributesOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $component = $__componentOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__componentOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php /**PATH D:\Laravel-App\filament\vendor\outerweb\filament-image-library\resources\views\filament\forms\components\image-library-cropper.blade.php ENDPATH**/ ?>