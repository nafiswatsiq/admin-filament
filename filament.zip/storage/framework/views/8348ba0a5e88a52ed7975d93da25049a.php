<?php
	$attributes = $attributes->merge([
	    'data-image-library' => 'image',
	]);
?>

<picture>
	<?php if($srcsetWebp): ?>
		<source
			srcset="<?php echo e($srcsetWebp); ?>"
			type="image/webp"
		/>
	<?php endif; ?>
	<?php if($srcset && $image): ?>
		<source
			srcset="<?php echo e($srcset); ?>"
			type="<?php echo e($image->mime_type); ?>"
		/>
	<?php endif; ?>
	<img
		src="<?php echo e($src); ?>"
		sizes="1px"
		title="<?php echo e($title); ?>"
		alt="<?php echo e($alt); ?>"
		width="<?php echo e($width); ?>"
		<?php echo e($attributes); ?>

	/>
</picture>
<?php /**PATH D:\Laravel-App\filament\vendor\outerweb\image-library\resources\views\components\picture.blade.php ENDPATH**/ ?>