<h3 class="mb-2 px-4 font-semibold text-lg text-gray-400">
    <span class="text-primary-400">❖</span>
    <?php echo e($status['title']); ?>

</h3>
<?php /**PATH D:\Laravel-App\filament\resources\views\vendor\filament-kanban\kanban-header.blade.php ENDPATH**/ ?>