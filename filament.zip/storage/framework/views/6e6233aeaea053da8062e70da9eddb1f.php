<?php
	$attributes = $attributes->merge([
	    'data-image-library' => 'image',
	    'data-image-library-id' => Str::uuid(),
	]);
?>

<img
	src="<?php echo e($src); ?>"
	srcset="<?php echo e($srcset); ?>"
	sizes="1px"
	title="<?php echo e($title); ?>"
	alt="<?php echo e($alt); ?>"
	width="<?php echo e($width); ?>"
	<?php echo e($attributes); ?>

/>
<?php /**PATH D:\Laravel-App\filament\vendor\outerweb\image-library\resources\views\components\image.blade.php ENDPATH**/ ?>