<?php if (isset($component)) { $__componentOriginalbe23554f7bded3778895289146189db7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbe23554f7bded3778895289146189db7 = $attributes; } ?>
<?php $component = Filament\View\LegacyComponents\Page::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Filament\View\LegacyComponents\Page::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
	<div class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3 mb-2">
		<?php $__empty_1 = true; $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<div
				class="relative overflhidden rounded-lg ring-1 ring-gray-950/10 dark:ring-white/20 bg-white dark:bg-gray-900"
			>
				<?php if (isset($component)) { $__componentOriginal310157662c158fee15e0626db88e7c9c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal310157662c158fee15e0626db88e7c9c = $attributes; } ?>
<?php $component = Outerweb\ImageLibrary\Components\Image::resolve(['image' => $image,'conversion' => 'filament-thumbnail'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('image-library-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Outerweb\ImageLibrary\Components\Image::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full','draggable' => 'false']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal310157662c158fee15e0626db88e7c9c)): ?>
<?php $attributes = $__attributesOriginal310157662c158fee15e0626db88e7c9c; ?>
<?php unset($__attributesOriginal310157662c158fee15e0626db88e7c9c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal310157662c158fee15e0626db88e7c9c)): ?>
<?php $component = $__componentOriginal310157662c158fee15e0626db88e7c9c; ?>
<?php unset($__componentOriginal310157662c158fee15e0626db88e7c9c); ?>
<?php endif; ?>
				<div class="flex flex-wrap justify-end items-center gap-3 p-3">
					<?php echo e($this->getCropAction()([
					    'id' => $image->id,
					])); ?>

					<?php echo e($this->getEditAction()([
					    'id' => $image->id,
					])); ?>

					<?php echo e($this->getDeleteAction()([
					    'id' => $image->id,
					])); ?>

				</div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<div class="text-gray-500 col-span-full text-center py-5">
				<?php echo e(__('filament-image-library::translations.no_images_found')); ?>

			</div>
		<?php endif; ?>
	</div>
	<?php if (isset($component)) { $__componentOriginal0c287a00f29f01c8f977078ff96faed4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0c287a00f29f01c8f977078ff96faed4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.pagination.index','data' => ['paginator' => $images,'pageOptions' => [12, 24, 48, 96],'currentPageOptionProperty' => 'itemsPerPage']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($images),'page-options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([12, 24, 48, 96]),'current-page-option-property' => 'itemsPerPage']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0c287a00f29f01c8f977078ff96faed4)): ?>
<?php $attributes = $__attributesOriginal0c287a00f29f01c8f977078ff96faed4; ?>
<?php unset($__attributesOriginal0c287a00f29f01c8f977078ff96faed4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c287a00f29f01c8f977078ff96faed4)): ?>
<?php $component = $__componentOriginal0c287a00f29f01c8f977078ff96faed4; ?>
<?php unset($__componentOriginal0c287a00f29f01c8f977078ff96faed4); ?>
<?php endif; ?>
	<?php if (isset($component)) { $__componentOriginal78918f4e4d2c3c3c2a4da34f24c77bf1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal78918f4e4d2c3c3c2a4da34f24c77bf1 = $attributes; } ?>
<?php $component = Outerweb\ImageLibrary\Components\Scripts::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('image-library-scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Outerweb\ImageLibrary\Components\Scripts::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal78918f4e4d2c3c3c2a4da34f24c77bf1)): ?>
<?php $attributes = $__attributesOriginal78918f4e4d2c3c3c2a4da34f24c77bf1; ?>
<?php unset($__attributesOriginal78918f4e4d2c3c3c2a4da34f24c77bf1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal78918f4e4d2c3c3c2a4da34f24c77bf1)): ?>
<?php $component = $__componentOriginal78918f4e4d2c3c3c2a4da34f24c77bf1; ?>
<?php unset($__componentOriginal78918f4e4d2c3c3c2a4da34f24c77bf1); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbe23554f7bded3778895289146189db7)): ?>
<?php $attributes = $__attributesOriginalbe23554f7bded3778895289146189db7; ?>
<?php unset($__attributesOriginalbe23554f7bded3778895289146189db7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbe23554f7bded3778895289146189db7)): ?>
<?php $component = $__componentOriginalbe23554f7bded3778895289146189db7; ?>
<?php unset($__componentOriginalbe23554f7bded3778895289146189db7); ?>
<?php endif; ?>
<?php /**PATH D:\Laravel-App\filament\vendor\outerweb\filament-image-library\resources\views\filament\pages\image-library.blade.php ENDPATH**/ ?>