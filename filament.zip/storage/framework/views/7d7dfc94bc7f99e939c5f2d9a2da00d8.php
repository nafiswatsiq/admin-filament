<div>
    <?php echo e($this->table); ?>

</div>
<?php /**PATH D:\Laravel-App\filament\vendor\joaopaulolndev\filament-edit-profile\resources\views\livewire\sanctum-tokens.blade.php ENDPATH**/ ?>