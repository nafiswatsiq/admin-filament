<div
    class="fi-in-placeholder text-sm leading-6 text-gray-400 dark:text-gray-500"
>
    <?php echo e($slot); ?>

</div>
<?php /**PATH D:\Laravel-App\filament\vendor\filament\infolists\resources\views\components\entries\placeholder.blade.php ENDPATH**/ ?>